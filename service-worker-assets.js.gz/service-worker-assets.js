self.assetsManifest = {
  "version": "V1uN+J4I",
  "assets": [
    {
      "hash": "sha256-arhFmDgtsVVMoMyAAFUAzDdXaKr7yt+mtyKAiR5HNl0=",
      "url": "Blog.styles.css"
    },
    {
      "hash": "sha256-aRguYPa2swmFRhWXp5PA0H+VprnUf/qFXF1wlT2dbxw=",
      "url": "_framework/Blog.j5hro0o3vp.wasm"
    },
    {
      "hash": "sha256-bOHBDXqcHAs3zIjmR6QO/aZQX74Xh45s9G5VY8ffBu8=",
      "url": "_framework/CsToml.Extensions.Configuration.8x03qwifgf.wasm"
    },
    {
      "hash": "sha256-3gJ3XPqDqyux5jmIAeW6bomaO11o+zPDwkFxPW1GYzg=",
      "url": "_framework/CsToml.igxf6k9624.wasm"
    },
    {
      "hash": "sha256-K46uy62cWedrCpQn6lDEUo+V41p7PfjIuAFHZSqvWjI=",
      "url": "_framework/Microsoft.AspNetCore.Components.7dtuqdr1r9.wasm"
    },
    {
      "hash": "sha256-CWCZqVZuK9hqJlOK6ywJw5UgVWe0Je7+KtO55A+f03k=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.d31aoxs14p.wasm"
    },
    {
      "hash": "sha256-bqToPI/iL7iT4lMfZpUf8kdGiSYBPn6stJz70lt8O9Q=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.2kw3cyk0ye.wasm"
    },
    {
      "hash": "sha256-HX68hXxk6c08Jqozrmk7hkVzJbe5mt8HQhQbxPCtE6A=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.pxmc3jrvol.wasm"
    },
    {
      "hash": "sha256-48JXlZmcPLcNSAjqhbdbfTH4xHqaohlFANKKDx/B8l8=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.jsatnke3be.wasm"
    },
    {
      "hash": "sha256-UPJuvhAAIQZIY0doC/uzYNM5QzRPAAU1Pmb0Ifrcf9c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.wcgatl1fku.wasm"
    },
    {
      "hash": "sha256-Wi80UmFVOmdQaDRcxp7/2T/GEuCOmgUlM9sNp0LaWnw=",
      "url": "_framework/Microsoft.Extensions.Configuration.acm92ptx9n.wasm"
    },
    {
      "hash": "sha256-s5NDC8ouuFz/geKtgUbDxufmI+ao9OBcshJqHZ7nCUs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.lmexob41u0.wasm"
    },
    {
      "hash": "sha256-7S6kTaJc+9LgeS7EUElf4KtAd5iKmMPQDq8blLM0R9A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.b6byw5pilb.wasm"
    },
    {
      "hash": "sha256-MsoKFauzZ1Q66tlPtOkEZW/Bmz1VSbNGsLrEhcdKzmQ=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.e9a5j13hq3.wasm"
    },
    {
      "hash": "sha256-nzOhOhbqPp4A+JOtHIaacnQTp3N4+NjIXJwngjl/YE8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.zfy5eiubms.wasm"
    },
    {
      "hash": "sha256-tDVeIP9ZR14ldjVq/eMrl96QyGZ2/GBm9sQHIp0/4MM=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.k414ve2zji.wasm"
    },
    {
      "hash": "sha256-YO5x91yf17Td+qEVJo/kUm3f6fHgTTb09Zq+lVN97UA=",
      "url": "_framework/Microsoft.Extensions.Logging.0sb8g1j1zh.wasm"
    },
    {
      "hash": "sha256-wCWCP/8cnVnRXChftitCfDP5dfqI0K+u5H1Mszt8oGw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.w4167e73p5.wasm"
    },
    {
      "hash": "sha256-t2HV7rTyAyGOMt33GRIJREnlQtukzdhWo1v4EH2gtKg=",
      "url": "_framework/Microsoft.Extensions.Options.hizer6y0kq.wasm"
    },
    {
      "hash": "sha256-jniVbDAf9oTw4t4bWQ1+z8B+AOK2d0BUwwfVeIKPAIE=",
      "url": "_framework/Microsoft.Extensions.Primitives.i4ptzcb4ar.wasm"
    },
    {
      "hash": "sha256-h5dZbpobwVaeAlG8/7omx0OFtwdJP8CG6fx00P0ms3E=",
      "url": "_framework/Microsoft.JSInterop.5x9l7rt3xd.wasm"
    },
    {
      "hash": "sha256-rhpkBOcrE3Jka5EriY0f6+d/lxnwAWpcDQrLBwRBYfg=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ynpjm7kaw7.wasm"
    },
    {
      "hash": "sha256-T3BCWwqsjEORcekFyj7XoM74fpnaKt+4nJBQ3kss7Kc=",
      "url": "_framework/System.Collections.Concurrent.peii6f0o9y.wasm"
    },
    {
      "hash": "sha256-QPEX/oPz0B5neRZ1nAUKYYh2Y8C1vVf86qD26pIQbdM=",
      "url": "_framework/System.Collections.Immutable.spyih4vlah.wasm"
    },
    {
      "hash": "sha256-lLTki6WXTeO7oo83mPrD8zXYIEqdF3KpBhLl/NlSa0Y=",
      "url": "_framework/System.Collections.k2dhj35jm2.wasm"
    },
    {
      "hash": "sha256-noCChWpPqP8UDDTdL80qq+7XGCL2qsC/7Zx9gYzl9pY=",
      "url": "_framework/System.ComponentModel.Primitives.mywjz8rekf.wasm"
    },
    {
      "hash": "sha256-EdstTP9IiGWSnfAiUfYQU/+yVLpIFnkDsEhkbUYb1Bk=",
      "url": "_framework/System.ComponentModel.nu6ttwym4t.wasm"
    },
    {
      "hash": "sha256-+Pfa1lhq2g6m/xmSrfHZ52KMh54hiHde3lTNY92NARY=",
      "url": "_framework/System.Console.crzccztc4c.wasm"
    },
    {
      "hash": "sha256-t/Cdsc0iNA0Uy9aw0iQ6CA8fmldsUCUqaCjNYed+IK8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.v254usz4o0.wasm"
    },
    {
      "hash": "sha256-jZ49LLJrRMhseD9o5OYSzmCm+XgVu6wmPYCWCgcs1bc=",
      "url": "_framework/System.IO.FileSystem.Watcher.99gdnlmva2.wasm"
    },
    {
      "hash": "sha256-XzDBdGq7YMok7HvhoSgJK2SG5YnBqgbSbj7y+8/5/UI=",
      "url": "_framework/System.IO.Hashing.zvmiwv33ql.wasm"
    },
    {
      "hash": "sha256-E4VoE/XaBWeeEAiyQ5Zc8DQIfLwyF8owdO0lDtxTddw=",
      "url": "_framework/System.IO.Pipelines.t4sa62ka9r.wasm"
    },
    {
      "hash": "sha256-zbQoYCaMOZVz35MIWRlWDvt/eW+LIE6T5lMbRHuWvA0=",
      "url": "_framework/System.Linq.liruu8xngt.wasm"
    },
    {
      "hash": "sha256-K+9UirNa3sSrr+z2IIk3X0jqxjUW0lXYVpZiqP9SlYc=",
      "url": "_framework/System.Memory.1h70b4fam4.wasm"
    },
    {
      "hash": "sha256-OoQtGDed2fX+oA3QdsREgcgqeRVkEe6+o6NmUh5LIT8=",
      "url": "_framework/System.Net.Http.2h2dugdthf.wasm"
    },
    {
      "hash": "sha256-Uk0ditO8bdDYxyo+Mqf617ae02ct5KsBUTQX0j3/Zmo=",
      "url": "_framework/System.Net.Primitives.usmh1pktcr.wasm"
    },
    {
      "hash": "sha256-y2C3CZtEAMvCdJxsNd/JCOikBig7U8PNawEGd52PbJ8=",
      "url": "_framework/System.Private.CoreLib.x9xjctd6xa.wasm"
    },
    {
      "hash": "sha256-tr3liJlWziryN9eHJ3U4R3og6zrNFmXtw5s4UB1jmps=",
      "url": "_framework/System.Private.Uri.iu0oogd47t.wasm"
    },
    {
      "hash": "sha256-ar6gsLvWfN3DMBEBih8s5NYwht43AL6tR5XvQ64amcY=",
      "url": "_framework/System.Runtime.6o3csyk0ik.wasm"
    },
    {
      "hash": "sha256-X5XfiyFL3dPqJQK1TsjZ7scPOPVKg6LQZWyLYRX0K+4=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.18wuw7xz41.wasm"
    },
    {
      "hash": "sha256-DPgmoOB/sZZ3QxDyh3b/606IMYKpS007s7u8rSk5DVY=",
      "url": "_framework/System.Runtime.Numerics.sw3dj0b8jb.wasm"
    },
    {
      "hash": "sha256-uDL86bdCFoycxoOOWRJqP74IeiFG3qDufuIVhWRBz0s=",
      "url": "_framework/System.Runtime.Serialization.Primitives.8sda9cpy12.wasm"
    },
    {
      "hash": "sha256-Q9xWrlm36939/qn+O74cXP0YCp30WnqVRz3GnIkhqjA=",
      "url": "_framework/System.Security.Cryptography.xjjfjwakjf.wasm"
    },
    {
      "hash": "sha256-YKPz9N6MUrKyCSeUmtIN6JxYb0rw9nbPdnmvnxQWQiY=",
      "url": "_framework/System.Text.Encodings.Web.ois9obo31x.wasm"
    },
    {
      "hash": "sha256-eMuBZlkxUgNrL2IW2VaUxnxbnT9B0tUnOePfSPNBNBk=",
      "url": "_framework/System.Text.Json.w6oo795rd5.wasm"
    },
    {
      "hash": "sha256-X4KtG2QRBaoDgRubGKJtjCxlH82rwR0q8JXTf3/+7yk=",
      "url": "_framework/System.Text.RegularExpressions.rxez4yg8h0.wasm"
    },
    {
      "hash": "sha256-7lCp9J2ErWw5HBKXGmMrurOrZP3mpspYdOiVKAgPuoU=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-0ne4uWkFIpW2NrYJe1nkb2D5LE7ftNu8RaTF/KezIuE=",
      "url": "_framework/dotnet.native.adtesk985n.wasm"
    },
    {
      "hash": "sha256-TFGxZWzGbQ56AOyEEIAvDwGrIJMs7z/oTCBzYSxmo44=",
      "url": "_framework/dotnet.native.w38hificuw.js"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-kjoJJWLb+lHEyEwsDpRL3qkc5QFRmsyh3CXaYvsqi7I=",
      "url": "appSettings.toml"
    },
    {
      "hash": "sha256-tMV4bywerCz6rr/XhH5VYzoCUXAccZ2OPTNwj5IRppo=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-zfZDxn93Pgt+mw0ggQTfd7xRgIQaski3U7yZS9xOsj0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-Zg+XZRI+LkFGenBWHVd1Ke5mFxce2FKbbM3+zLMyAKo=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-nMPM066johB7WfL3lmbDgNFkbIyMo8irk6g9SzT+ARY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-6kXckefe5XHvO0l6SVtREzHSLnQIJNMdTia3TUHb78U=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-57uOHyiG7A4su/idyJlcX4nL63zWN0gM4dCAEsI2BDM=",
      "url": "post_images/20250719_TomlDocument.svg"
    },
    {
      "hash": "sha256-Yk224G0PbdHeIhMr0aRhgcpnRRk7oElnZ7Q/TF6RwTY=",
      "url": "post_images/20250911_service-worker.published.js.png"
    }
  ]
};
