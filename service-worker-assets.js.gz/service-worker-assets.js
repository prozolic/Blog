self.assetsManifest = {
  "version": "3bgp9WJT",
  "assets": [
    {
      "hash": "sha256-OHHIqtETA8sOsLrBrXP85NlpjUnVcjyfFiqiX+R6re4=",
      "url": "Blog.styles.css"
    },
    {
      "hash": "sha256-W3OEDKtXLU+//Fw0mvT8ceHZvfEiQmKmhRsqJdsQ6TY=",
      "url": "_framework/Blog.5g2tn1sc2v.wasm"
    },
    {
      "hash": "sha256-ZpBHelPtBz2+mnx09E7rVibYeYSymgSMID+GA1fdSh8=",
      "url": "_framework/CsToml.Extensions.Configuration.a05h0ngmxv.wasm"
    },
    {
      "hash": "sha256-9BBQUzk/v6Oj1s+HYBlSKdTvBgFyuM0ER7uqz75ID4w=",
      "url": "_framework/CsToml.otmmmfqnt0.wasm"
    },
    {
      "hash": "sha256-Pez03BohrvL4ngASIT3phdGymYzkqc8gDfSzw6sabS0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.byrlz0xip8.wasm"
    },
    {
      "hash": "sha256-C0FQBE3JHG4souaeRokxyuNxtgXEh6juI1aw2z9uUqI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.n5w1gihtwa.wasm"
    },
    {
      "hash": "sha256-U0dlMm4/h5UfML865FXgdnFIpdQIDLtyOO53Q5J874o=",
      "url": "_framework/Microsoft.AspNetCore.Components.j00196dpe2.wasm"
    },
    {
      "hash": "sha256-iCT5EnmwrM9VIGs6rOJEPRVqdL4VHuWzbT7UNBL2Llo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.occs3p1k63.wasm"
    },
    {
      "hash": "sha256-tMO9vrx1gEFPYxofdP6IprO3f8PmZ8GYyJX/pYEgifw=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.8ry3xodwaq.wasm"
    },
    {
      "hash": "sha256-TxOo9nPmVL3U9K4TaX1871k0es8meg5RhQtvn2xXGbc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.x8nc4ezhyo.wasm"
    },
    {
      "hash": "sha256-pSqj1QGxLxuEcPZWVLjEpLspqknRm3cDKxWgP/DU2dY=",
      "url": "_framework/Microsoft.Extensions.Configuration.f3uk0k3kni.wasm"
    },
    {
      "hash": "sha256-eW9Ik36CHy3X+VvBpurkHVndtOE5V2DCNek3LqA8XGs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bj994pzhzn.wasm"
    },
    {
      "hash": "sha256-5gwu0mYaoqPKE60PdSEdUGhQZoxYbCm0UBH1Hm+hZa8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.iqantsnbh2.wasm"
    },
    {
      "hash": "sha256-v1QoedSQ7pgyS4GGJppjcTrCrPaeRbMKqaEP2UrKGo0=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.b586uigmtj.wasm"
    },
    {
      "hash": "sha256-FlxHwMd4VUT/mLgFrUJoI+z17llE+n9VWcX93vXO8Ag=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.mphxgzxplm.wasm"
    },
    {
      "hash": "sha256-8urC0iObPZwjXdXVPOmKCjVFsyofDAkd266dboj96D8=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.exwtvgu8zw.wasm"
    },
    {
      "hash": "sha256-gs/JC5tuLkMEa2JoCD6v30RSChN9EItOmSpzwLKgNpA=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.mvhovwuytl.wasm"
    },
    {
      "hash": "sha256-d++3uvri7GMhyWGbCjeyHzOWjuav1kcihRQITVUffMk=",
      "url": "_framework/Microsoft.Extensions.Logging.bjke0ozgr8.wasm"
    },
    {
      "hash": "sha256-ZAdi1Ryb2ERqVtMWnjlTZUw216wfhU2pTLgmmt/e3/8=",
      "url": "_framework/Microsoft.Extensions.Options.gtojj40aw5.wasm"
    },
    {
      "hash": "sha256-xehjO81pBR+3CPulUKQ1p+5ZvAOUTuu7G14hZUeVSks=",
      "url": "_framework/Microsoft.Extensions.Primitives.j6t2jx47c2.wasm"
    },
    {
      "hash": "sha256-rhpkBOcrE3Jka5EriY0f6+d/lxnwAWpcDQrLBwRBYfg=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ynpjm7kaw7.wasm"
    },
    {
      "hash": "sha256-aQeliH0ZpGoqPJG6wf7fVBBQYe7PJFAIvBED+ssY7J4=",
      "url": "_framework/Microsoft.JSInterop.trga4cqfu3.wasm"
    },
    {
      "hash": "sha256-zLMEfr1PhQqm4FK6wc6BOrYTs0v0ygRsdFJXgNcMbGo=",
      "url": "_framework/System.Collections.0l0doscp0q.wasm"
    },
    {
      "hash": "sha256-o0JSGRxNTlqE5HRBJjyURO71vj2ihBtCdEfRSS0sztA=",
      "url": "_framework/System.Collections.Concurrent.dsmgidciti.wasm"
    },
    {
      "hash": "sha256-wxFdKHSEVBDCTzMUk4/j0x9UXxWmbk3FYLV2aW7cKJs=",
      "url": "_framework/System.Collections.Immutable.527yytqkeb.wasm"
    },
    {
      "hash": "sha256-6HwVPrxCGJ1cZIG0pjdKXqxCVZ5Z9n0jYbPsQ/EgquM=",
      "url": "_framework/System.ComponentModel.Primitives.0a0e8ng3my.wasm"
    },
    {
      "hash": "sha256-QD1DVHIO0+qjM/srw8UNWViolwFgILe7Ow44CMx7z8A=",
      "url": "_framework/System.ComponentModel.oqggmdaxu6.wasm"
    },
    {
      "hash": "sha256-GoZzMfzHVDboYRH+T3g4umNB1ZpTtehNQefx8qA2DqA=",
      "url": "_framework/System.Console.2d5vlmoaak.wasm"
    },
    {
      "hash": "sha256-BZ8Ido94HBU2wJZ9rAM57YgHYHKejZWJNTElL1sB+Pg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.hpnki68944.wasm"
    },
    {
      "hash": "sha256-wdOWz4N8xI98827evR3VDJdExzobWbT3u+CTwz+b2/E=",
      "url": "_framework/System.IO.FileSystem.Watcher.lz85rzbsqr.wasm"
    },
    {
      "hash": "sha256-+ExLOgvSPdjPwi5cJHIj2mLKbkc5glXPhCTJPPP8QBA=",
      "url": "_framework/System.IO.Hashing.0ae34popca.wasm"
    },
    {
      "hash": "sha256-Cq0NeKsXoRaPsbxb7OBQ6NnyKZkqdbE7q//xxwkkCgQ=",
      "url": "_framework/System.IO.Pipelines.qnefvvg4l1.wasm"
    },
    {
      "hash": "sha256-M3ZFznUzNK/Nmz/1U+f573xYeFfbnzbPHz6GosKNhgk=",
      "url": "_framework/System.Linq.pd62tkv8wu.wasm"
    },
    {
      "hash": "sha256-BhItnSTkNjVVRM2vVNVO1gsU1XvNwdNSLmfYWgrgbek=",
      "url": "_framework/System.Memory.avm18g6dhw.wasm"
    },
    {
      "hash": "sha256-7x2d/dgs4hTQQR3adOV4h6yyAfSjvQwog6WxvTq/f+E=",
      "url": "_framework/System.Net.Http.dh6lyvh6d4.wasm"
    },
    {
      "hash": "sha256-exVzRHBEzceG5mT//e3FmIs/YQwdpSLZxD5DYN0KTC4=",
      "url": "_framework/System.Net.Primitives.9zps8c8diq.wasm"
    },
    {
      "hash": "sha256-9hco2X0sIaUdRyBhM4bv8Y45SZSDaAh1yd9a+THWbTQ=",
      "url": "_framework/System.Private.CoreLib.ar6z7hotkr.wasm"
    },
    {
      "hash": "sha256-oQwm/6MDF79+vUGFe/3vmgmKMF2aObUxU5FV0W3XBk4=",
      "url": "_framework/System.Private.Uri.l36rl4jfe7.wasm"
    },
    {
      "hash": "sha256-cTDlU0sLp3hCmTKUK2AVqrlAjuFjQveVBhCUZiIdUkc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lnedh9fxsl.wasm"
    },
    {
      "hash": "sha256-Jx6zVQ8VTFCd0rjXGCnq2cohKvwZxypj/FtSJp850xE=",
      "url": "_framework/System.Runtime.Numerics.x2zh25q0c1.wasm"
    },
    {
      "hash": "sha256-DtUUSpvnsnHtLd+vAdRddhcTja5xn68rs+7jSgPxzyc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.2w3lcip6bk.wasm"
    },
    {
      "hash": "sha256-fzUPh1z2poey1lWmt+HG00uVguNJ5xqxmMX6TrhQajk=",
      "url": "_framework/System.Runtime.x49huxw6xv.wasm"
    },
    {
      "hash": "sha256-vbX+Srd8g66Oceyfdlzav9S4o1vaU7Ygi9F/Piexmm0=",
      "url": "_framework/System.Security.Cryptography.7j1iu5ang0.wasm"
    },
    {
      "hash": "sha256-c5RLUrDt4sG/1BUZLDKBL/8r3macGjhggRplXaBWcBQ=",
      "url": "_framework/System.Text.Encodings.Web.17hm3y46w3.wasm"
    },
    {
      "hash": "sha256-AHJREPEaIs6sAFVKZ0EIWv025BY8Kud9tqD1kYBgoHA=",
      "url": "_framework/System.Text.Json.kru1kefv85.wasm"
    },
    {
      "hash": "sha256-cssgrj2fLKJui+a09EbhoMvUEqUJHPWKR47Ri3l887A=",
      "url": "_framework/System.Text.RegularExpressions.uppli1il33.wasm"
    },
    {
      "hash": "sha256-WHSVxGAl1BTs6pQFombunoMxy0l8XhtrLJlglQG+fNk=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-3MHpnImjcdbndre7BEBFmcZQ61mhKqldc9b5Bpp44Xo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-57XReqWWAB6pfa7h+IyW0lp9W0UdTvkuU79rv9QoKyI=",
      "url": "_framework/dotnet.native.12132ogaml.wasm"
    },
    {
      "hash": "sha256-e8yPPAIutQrVipU5SyixzNeHMyQJZ21IPy3EZ8vn6v4=",
      "url": "_framework/dotnet.native.9zlpwida0q.js"
    },
    {
      "hash": "sha256-x+PnWU47EIr/zL3xxqIUMDJi/dy5904TVGunDqCvjIY=",
      "url": "_framework/dotnet.runtime.593bvuk5yc.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-rnqXCovcfgHmKC8LaoxQtxQ01TAE1l4x+LYbpxdSh5k=",
      "url": "appSettings.toml"
    },
    {
      "hash": "sha256-TQfoK6v4S9BxxuA/kmKnvZ+W02kSQLGNXy2x5KGYmoE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-zfZDxn93Pgt+mw0ggQTfd7xRgIQaski3U7yZS9xOsj0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-Zg+XZRI+LkFGenBWHVd1Ke5mFxce2FKbbM3+zLMyAKo=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-N5EK7II2Um8C/Ost5qIpcsp4oDQsmyQG4pmgdpdgQ9U=",
      "url": "index.html"
    },
    {
      "hash": "sha256-eeSJpVUPaB8WV/aaHOBlik2BJ82ClFlmOPtHQmOBjuI=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-57uOHyiG7A4su/idyJlcX4nL63zWN0gM4dCAEsI2BDM=",
      "url": "post_images/20250719_TomlDocument.svg"
    }
  ]
};
