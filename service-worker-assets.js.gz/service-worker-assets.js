self.assetsManifest = {
  "version": "cZ2YGXvB",
  "assets": [
    {
      "hash": "sha256-OHHIqtETA8sOsLrBrXP85NlpjUnVcjyfFiqiX+R6re4=",
      "url": "Blog.styles.css"
    },
    {
      "hash": "sha256-zjig913MRBbVDFuPG2YdFiI8dWkx8IeS0LBMYgrpiik=",
      "url": "_framework/Blog.mbpc4e4odv.wasm"
    },
    {
      "hash": "sha256-ZpBHelPtBz2+mnx09E7rVibYeYSymgSMID+GA1fdSh8=",
      "url": "_framework/CsToml.Extensions.Configuration.a05h0ngmxv.wasm"
    },
    {
      "hash": "sha256-9BBQUzk/v6Oj1s+HYBlSKdTvBgFyuM0ER7uqz75ID4w=",
      "url": "_framework/CsToml.otmmmfqnt0.wasm"
    },
    {
      "hash": "sha256-Pez03BohrvL4ngASIT3phdGymYzkqc8gDfSzw6sabS0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.byrlz0xip8.wasm"
    },
    {
      "hash": "sha256-C0FQBE3JHG4souaeRokxyuNxtgXEh6juI1aw2z9uUqI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.n5w1gihtwa.wasm"
    },
    {
      "hash": "sha256-U0dlMm4/h5UfML865FXgdnFIpdQIDLtyOO53Q5J874o=",
      "url": "_framework/Microsoft.AspNetCore.Components.j00196dpe2.wasm"
    },
    {
      "hash": "sha256-iCT5EnmwrM9VIGs6rOJEPRVqdL4VHuWzbT7UNBL2Llo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.occs3p1k63.wasm"
    },
    {
      "hash": "sha256-tMO9vrx1gEFPYxofdP6IprO3f8PmZ8GYyJX/pYEgifw=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.8ry3xodwaq.wasm"
    },
    {
      "hash": "sha256-TxOo9nPmVL3U9K4TaX1871k0es8meg5RhQtvn2xXGbc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.x8nc4ezhyo.wasm"
    },
    {
      "hash": "sha256-pSqj1QGxLxuEcPZWVLjEpLspqknRm3cDKxWgP/DU2dY=",
      "url": "_framework/Microsoft.Extensions.Configuration.f3uk0k3kni.wasm"
    },
    {
      "hash": "sha256-eW9Ik36CHy3X+VvBpurkHVndtOE5V2DCNek3LqA8XGs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bj994pzhzn.wasm"
    },
    {
      "hash": "sha256-5gwu0mYaoqPKE60PdSEdUGhQZoxYbCm0UBH1Hm+hZa8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.iqantsnbh2.wasm"
    },
    {
      "hash": "sha256-v1QoedSQ7pgyS4GGJppjcTrCrPaeRbMKqaEP2UrKGo0=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.b586uigmtj.wasm"
    },
    {
      "hash": "sha256-FlxHwMd4VUT/mLgFrUJoI+z17llE+n9VWcX93vXO8Ag=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.mphxgzxplm.wasm"
    },
    {
      "hash": "sha256-8urC0iObPZwjXdXVPOmKCjVFsyofDAkd266dboj96D8=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.exwtvgu8zw.wasm"
    },
    {
      "hash": "sha256-gs/JC5tuLkMEa2JoCD6v30RSChN9EItOmSpzwLKgNpA=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.mvhovwuytl.wasm"
    },
    {
      "hash": "sha256-d++3uvri7GMhyWGbCjeyHzOWjuav1kcihRQITVUffMk=",
      "url": "_framework/Microsoft.Extensions.Logging.bjke0ozgr8.wasm"
    },
    {
      "hash": "sha256-ZAdi1Ryb2ERqVtMWnjlTZUw216wfhU2pTLgmmt/e3/8=",
      "url": "_framework/Microsoft.Extensions.Options.gtojj40aw5.wasm"
    },
    {
      "hash": "sha256-xehjO81pBR+3CPulUKQ1p+5ZvAOUTuu7G14hZUeVSks=",
      "url": "_framework/Microsoft.Extensions.Primitives.j6t2jx47c2.wasm"
    },
    {
      "hash": "sha256-rhpkBOcrE3Jka5EriY0f6+d/lxnwAWpcDQrLBwRBYfg=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ynpjm7kaw7.wasm"
    },
    {
      "hash": "sha256-aQeliH0ZpGoqPJG6wf7fVBBQYe7PJFAIvBED+ssY7J4=",
      "url": "_framework/Microsoft.JSInterop.trga4cqfu3.wasm"
    },
    {
      "hash": "sha256-KGJVPD0cwx55ID3JFmJnpYtUXk3/lDfYlRou/xgNWBU=",
      "url": "_framework/System.Collections.Concurrent.gmcdhky5gf.wasm"
    },
    {
      "hash": "sha256-3Zsxyx+d27IROD/Q0CVl6vwK/jr01dS3BAEUNuwYbh0=",
      "url": "_framework/System.Collections.Immutable.xrni7r65kn.wasm"
    },
    {
      "hash": "sha256-pc50/pxDdn72Qcu2VWnnLGoGhfnU57xa8jFWuj42R+8=",
      "url": "_framework/System.Collections.zu0c2cnlii.wasm"
    },
    {
      "hash": "sha256-mFHukPC7WRfk3ZBpRxi3wZkIX/NHZyrvsv5LzY81Ruw=",
      "url": "_framework/System.ComponentModel.Primitives.wqmpniv2fp.wasm"
    },
    {
      "hash": "sha256-7n7ghIpXsa9b0B2ogCKFeKszbubZfTop3s6xAVOqZ9I=",
      "url": "_framework/System.ComponentModel.ek5njsetz3.wasm"
    },
    {
      "hash": "sha256-1RTIttLLMiBpC/m4TMtLalGLefFF+lxQbe2YNUrbb+g=",
      "url": "_framework/System.Console.9fnpmfyd1i.wasm"
    },
    {
      "hash": "sha256-/qNm4vyBF5rvWArhWxEGFj0meXsDZTNNiuOTIAMU/iU=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.y8k2lhb34p.wasm"
    },
    {
      "hash": "sha256-GA6AZTqiu0cyXHPlPVUmAoPTvOQv6j+bVqNriQaXJnk=",
      "url": "_framework/System.IO.FileSystem.Watcher.oclcz1nsi8.wasm"
    },
    {
      "hash": "sha256-+ExLOgvSPdjPwi5cJHIj2mLKbkc5glXPhCTJPPP8QBA=",
      "url": "_framework/System.IO.Hashing.0ae34popca.wasm"
    },
    {
      "hash": "sha256-VjMc+cxcFemZBof4Ce5RXYMPcbClbUD5gFoMpgP3wJw=",
      "url": "_framework/System.IO.Pipelines.urg354q4ee.wasm"
    },
    {
      "hash": "sha256-OowsI2vNq66fu58yfWlnu3MOnNY7NICAV1p8B1q2E+4=",
      "url": "_framework/System.Linq.uia6hykp8a.wasm"
    },
    {
      "hash": "sha256-n2/tmH0VBROMgwWqxLCft9rg8CK7KUMy0LQwTSu3tIs=",
      "url": "_framework/System.Memory.18cqs1xqkc.wasm"
    },
    {
      "hash": "sha256-0ShysY0dgxKUht6+FiJw+yqLEYG2HgUbelJ6RKeXTqg=",
      "url": "_framework/System.Net.Http.zntgxj72k8.wasm"
    },
    {
      "hash": "sha256-lpuToxoC6gyjBIE2Z0NrXP7Q+Zku/Hml1ND72k+jG48=",
      "url": "_framework/System.Net.Primitives.qk8k4u090q.wasm"
    },
    {
      "hash": "sha256-m7Tf/HABAQ9nhWYqSEXtl0XYnTuohKu7/ZZQTJvgt+s=",
      "url": "_framework/System.Private.CoreLib.j6b003dncu.wasm"
    },
    {
      "hash": "sha256-GX/HBwI/7ppZ6Koj0pMFXXkEziSmDt66AQ7ndOtOikk=",
      "url": "_framework/System.Private.Uri.po2qfkbg25.wasm"
    },
    {
      "hash": "sha256-ITECDI9uTvAlpMFKoVaIu8maj0X2Kt1DckYtWUghRVE=",
      "url": "_framework/System.Runtime.53fzi652ci.wasm"
    },
    {
      "hash": "sha256-3IoLyXDPZlSSNuf0cCFYH/6pnHsiIz+bg/ptKuGnMiI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4wymnd9fjf.wasm"
    },
    {
      "hash": "sha256-+d4P7bsoeDjU27UJWe8hvPTsmC5IT8kWJDjlyDn1kyk=",
      "url": "_framework/System.Runtime.Numerics.viuac7yhs7.wasm"
    },
    {
      "hash": "sha256-yJ9LZBU/HpWdphQ+yR9mXJGdEXZrgthtYm5COu2QVtE=",
      "url": "_framework/System.Runtime.Serialization.Primitives.gii6h75lbo.wasm"
    },
    {
      "hash": "sha256-GHhLOyVmHw2ShwjsXAcwzED8flStKR43wHWNgCFnC0w=",
      "url": "_framework/System.Security.Cryptography.o87prjjpi8.wasm"
    },
    {
      "hash": "sha256-3cJRUrFjSoiaGlI3OmHNndawtN8Y5lEgLHYI76jlAvo=",
      "url": "_framework/System.Text.Encodings.Web.j8jbnca1on.wasm"
    },
    {
      "hash": "sha256-ewU++qEOKOMlUm9nDrFDj/MdZHO5SBIk8YtndybPHj8=",
      "url": "_framework/System.Text.Json.vrh6yp4jdc.wasm"
    },
    {
      "hash": "sha256-sXTH9c57ccmOHrE+Bpsiewg0xWGtHrbl8KBKpTJW9VA=",
      "url": "_framework/System.Text.RegularExpressions.3zydt3n8n9.wasm"
    },
    {
      "hash": "sha256-fBmYO3v3MQW7T0aCIEbVWv8j5x/OWM6t2qR3QmhvDsc=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-VSrDABliXym1uaVGf/4XAZdHT7sA5xiMiD/TmJeALDc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-dGmZXUuDnT/7FyqwscWAnv++/se7ACzUBXOc3iNpI+g=",
      "url": "_framework/dotnet.native.c8avxgdel6.js"
    },
    {
      "hash": "sha256-v8DqYrw+QwPp7RAgP2XVp7kNwoGXWargkaM1ydlf2OM=",
      "url": "_framework/dotnet.native.hkyxig4hrn.wasm"
    },
    {
      "hash": "sha256-gbZjXNFbH7V8lcix+H0TUDJHLeFUA3n3IMu7fLh4D80=",
      "url": "_framework/dotnet.runtime.d1pzlaz2ez.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-rnqXCovcfgHmKC8LaoxQtxQ01TAE1l4x+LYbpxdSh5k=",
      "url": "appSettings.toml"
    },
    {
      "hash": "sha256-TQfoK6v4S9BxxuA/kmKnvZ+W02kSQLGNXy2x5KGYmoE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-zfZDxn93Pgt+mw0ggQTfd7xRgIQaski3U7yZS9xOsj0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-Zg+XZRI+LkFGenBWHVd1Ke5mFxce2FKbbM3+zLMyAKo=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9lvfExji5nPVk1wPvvLhH7BUW7Zyy1YKL3/gqhQDoXo=",
      "url": "index.html"
    },
    {
      "hash": "sha256-eeSJpVUPaB8WV/aaHOBlik2BJ82ClFlmOPtHQmOBjuI=",
      "url": "manifest.webmanifest"
    }
  ]
};
