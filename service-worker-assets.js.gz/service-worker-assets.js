self.assetsManifest = {
  "version": "T0oy7HQD",
  "assets": [
    {
      "hash": "sha256-OHHIqtETA8sOsLrBrXP85NlpjUnVcjyfFiqiX+R6re4=",
      "url": "Blog.styles.css"
    },
    {
      "hash": "sha256-7NCKswruBehXLVkV8xk9Ih98LlPRC+DO4DJxyBvAtAM=",
      "url": "_framework/Blog.g3jdjz5erq.wasm"
    },
    {
      "hash": "sha256-t9copO/gqydkA6ZDIj88cF1Ag+Aj86gjSqOXxLKFvjg=",
      "url": "_framework/CsToml.Extensions.Configuration.742oj1q61u.wasm"
    },
    {
      "hash": "sha256-vAiwkuAxP8KBq0l/pv+oqaOl4BilJc4a7zEsTimsrx8=",
      "url": "_framework/CsToml.cu04ujt5y5.wasm"
    },
    {
      "hash": "sha256-QERpDp7lHlbiW8Y16WysL+zgHIO3G0UAKyBYXrCweWU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.823heldmjd.wasm"
    },
    {
      "hash": "sha256-bqToPI/iL7iT4lMfZpUf8kdGiSYBPn6stJz70lt8O9Q=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.2kw3cyk0ye.wasm"
    },
    {
      "hash": "sha256-VMLq1T7ugDvIl91VrLs2KSetiJhaK6p5WbfPRk7tGy0=",
      "url": "_framework/Microsoft.AspNetCore.Components.k2pruujta3.wasm"
    },
    {
      "hash": "sha256-HX68hXxk6c08Jqozrmk7hkVzJbe5mt8HQhQbxPCtE6A=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.pxmc3jrvol.wasm"
    },
    {
      "hash": "sha256-48JXlZmcPLcNSAjqhbdbfTH4xHqaohlFANKKDx/B8l8=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.jsatnke3be.wasm"
    },
    {
      "hash": "sha256-UPJuvhAAIQZIY0doC/uzYNM5QzRPAAU1Pmb0Ifrcf9c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.wcgatl1fku.wasm"
    },
    {
      "hash": "sha256-Wi80UmFVOmdQaDRcxp7/2T/GEuCOmgUlM9sNp0LaWnw=",
      "url": "_framework/Microsoft.Extensions.Configuration.acm92ptx9n.wasm"
    },
    {
      "hash": "sha256-s5NDC8ouuFz/geKtgUbDxufmI+ao9OBcshJqHZ7nCUs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.lmexob41u0.wasm"
    },
    {
      "hash": "sha256-7S6kTaJc+9LgeS7EUElf4KtAd5iKmMPQDq8blLM0R9A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.b6byw5pilb.wasm"
    },
    {
      "hash": "sha256-MsoKFauzZ1Q66tlPtOkEZW/Bmz1VSbNGsLrEhcdKzmQ=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.e9a5j13hq3.wasm"
    },
    {
      "hash": "sha256-nzOhOhbqPp4A+JOtHIaacnQTp3N4+NjIXJwngjl/YE8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.zfy5eiubms.wasm"
    },
    {
      "hash": "sha256-tDVeIP9ZR14ldjVq/eMrl96QyGZ2/GBm9sQHIp0/4MM=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.k414ve2zji.wasm"
    },
    {
      "hash": "sha256-YO5x91yf17Td+qEVJo/kUm3f6fHgTTb09Zq+lVN97UA=",
      "url": "_framework/Microsoft.Extensions.Logging.0sb8g1j1zh.wasm"
    },
    {
      "hash": "sha256-wCWCP/8cnVnRXChftitCfDP5dfqI0K+u5H1Mszt8oGw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.w4167e73p5.wasm"
    },
    {
      "hash": "sha256-t2HV7rTyAyGOMt33GRIJREnlQtukzdhWo1v4EH2gtKg=",
      "url": "_framework/Microsoft.Extensions.Options.hizer6y0kq.wasm"
    },
    {
      "hash": "sha256-jniVbDAf9oTw4t4bWQ1+z8B+AOK2d0BUwwfVeIKPAIE=",
      "url": "_framework/Microsoft.Extensions.Primitives.i4ptzcb4ar.wasm"
    },
    {
      "hash": "sha256-h5dZbpobwVaeAlG8/7omx0OFtwdJP8CG6fx00P0ms3E=",
      "url": "_framework/Microsoft.JSInterop.5x9l7rt3xd.wasm"
    },
    {
      "hash": "sha256-rhpkBOcrE3Jka5EriY0f6+d/lxnwAWpcDQrLBwRBYfg=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ynpjm7kaw7.wasm"
    },
    {
      "hash": "sha256-lc2mCZ2KSeeQ/heB5ZqbRIZWeJd/IQRiN0+kjJqtO8k=",
      "url": "_framework/System.Collections.Concurrent.vz6wz12u1b.wasm"
    },
    {
      "hash": "sha256-XIvmRDFxDnf9Os51wbR4XZhsE4noUpDKUXYVsQ6JXDw=",
      "url": "_framework/System.Collections.Immutable.ghrqbvi6mq.wasm"
    },
    {
      "hash": "sha256-9jg1jKWgYdqxa3uEpxVqyBgM3YRjCMzDoH1C9NeLmo4=",
      "url": "_framework/System.Collections.iinkbu7eys.wasm"
    },
    {
      "hash": "sha256-JtYmyTE9AYSAnGzyNxVqT8gwe9gPOoovgSe9OgWtBbM=",
      "url": "_framework/System.ComponentModel.Primitives.uvui17mh69.wasm"
    },
    {
      "hash": "sha256-5inQh8bubMrlto3Kwxx9iM27KpcXN8152RWX745jLso=",
      "url": "_framework/System.ComponentModel.e3q0ysgg90.wasm"
    },
    {
      "hash": "sha256-Q+2ODjB9hicuwY5Zrfa61sNpP74MpMt5wybaira+EoU=",
      "url": "_framework/System.Console.34bwhr72vw.wasm"
    },
    {
      "hash": "sha256-6IXZ3jYbsqehTroRDahFj5cVjUjHkm666s4Cd1vPbTs=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.wesh0cio9z.wasm"
    },
    {
      "hash": "sha256-yl02461eshi6mZtPUYbr5MTGZr1+LNJg477icgPV01E=",
      "url": "_framework/System.IO.FileSystem.Watcher.id5s0qzfgj.wasm"
    },
    {
      "hash": "sha256-XzDBdGq7YMok7HvhoSgJK2SG5YnBqgbSbj7y+8/5/UI=",
      "url": "_framework/System.IO.Hashing.zvmiwv33ql.wasm"
    },
    {
      "hash": "sha256-kQhGbfR4YHaP3eHHZP75W/skcNJinLE6KDD1EzMBcJ8=",
      "url": "_framework/System.IO.Pipelines.7encqb16xz.wasm"
    },
    {
      "hash": "sha256-EY/0IR6wLtK4WmGBGERBpVFPkIwG+1fG4Bs+QMY8+Rw=",
      "url": "_framework/System.Linq.vg51fkyxzn.wasm"
    },
    {
      "hash": "sha256-94MpW0XOzu1dfEnEel+szxs7l42xpW1vPSgBCajH2xU=",
      "url": "_framework/System.Memory.jpq36hra73.wasm"
    },
    {
      "hash": "sha256-TYGMd5WocFjF3HNxKe4d8ZPRRmqIfaaQQnPTmvakcIs=",
      "url": "_framework/System.Net.Http.vpx4jig6ry.wasm"
    },
    {
      "hash": "sha256-+3he3hGsJ68EWFFV7iT8Rdys7AkZ8yeGmLFdfG01pUA=",
      "url": "_framework/System.Net.Primitives.nt1bv37byl.wasm"
    },
    {
      "hash": "sha256-S0ycfFhm8I4k0cswUECEkxWPCBuL6fUzTvQ/ROb2G5A=",
      "url": "_framework/System.Private.CoreLib.v30jlglcf5.wasm"
    },
    {
      "hash": "sha256-bFD6RPItWc9GXx5IZG+i1L0IwS0V2qB8Qngpb6suSRM=",
      "url": "_framework/System.Private.Uri.4a8ii1eyat.wasm"
    },
    {
      "hash": "sha256-mCeEnV+s7uih9ScHdixDnueOK/k+dNtcpSQ9B4BW1V8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.06941s83e9.wasm"
    },
    {
      "hash": "sha256-PiOCWrvU0vNSvHF0oHJu6r3FmK0zTPFQOF4pJpLZkbI=",
      "url": "_framework/System.Runtime.Numerics.62b9bmwa3d.wasm"
    },
    {
      "hash": "sha256-rvjbxuk85te10RorutejwSCTrmWs1+eUdsapI/htXg0=",
      "url": "_framework/System.Runtime.Serialization.Primitives.aupm7lkzt5.wasm"
    },
    {
      "hash": "sha256-yMDmpKRe1fj7RJnn+bnI+eziJmSs/YNyZwGRuHfl82A=",
      "url": "_framework/System.Runtime.cr6cet7jts.wasm"
    },
    {
      "hash": "sha256-eOd0fkktIBiZaWSOqbo2jMr6mLQd5/bLipWUEvJUU44=",
      "url": "_framework/System.Security.Cryptography.k9njsc1rkn.wasm"
    },
    {
      "hash": "sha256-Gu1Mb9AVWHond3IJVe0yyk94ew2fIeTLesVPzfvIf/A=",
      "url": "_framework/System.Text.Encodings.Web.y271734m7f.wasm"
    },
    {
      "hash": "sha256-XeQLINYcaVHQI5kXSkDz7O0JOjk59aPYwflJRMO7rvY=",
      "url": "_framework/System.Text.Json.rqibszmqw7.wasm"
    },
    {
      "hash": "sha256-B6mfarMQHmj2l+9cpmKnE3SEZXQtdv3mXgwSB9EoR0I=",
      "url": "_framework/System.Text.RegularExpressions.h2mpndpv4w.wasm"
    },
    {
      "hash": "sha256-Zo7m3+pLlbI3deLkmZUug6hqaaLithIm4H3s2sbWdXs=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wYjSscllRgsaXH0VUEf8zSZw/5lACwcJOUm+1THG5bk=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HlAj9t0WxNSsYgQ545lKS8IBedgDgQxmMBVfRQxDkPU=",
      "url": "_framework/dotnet.native.e9tvujs99f.js"
    },
    {
      "hash": "sha256-3rNSp6i7i6fpZX+9QDpfTj7wGT7la59U+bj32SsMuDk=",
      "url": "_framework/dotnet.native.el6ri4h8kv.wasm"
    },
    {
      "hash": "sha256-Isv/63htfX73xgn3/2cZMtk4S8xBcbmlXRgJMDv4mhI=",
      "url": "_framework/dotnet.runtime.ew19f13umk.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-rnqXCovcfgHmKC8LaoxQtxQ01TAE1l4x+LYbpxdSh5k=",
      "url": "appSettings.toml"
    },
    {
      "hash": "sha256-HPLEzlTP04u3snVPywdSvvoV41ymtf39AqrOe583Cog=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-zfZDxn93Pgt+mw0ggQTfd7xRgIQaski3U7yZS9xOsj0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-Zg+XZRI+LkFGenBWHVd1Ke5mFxce2FKbbM3+zLMyAKo=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-SX9MoCwdJ0p5VxgmlRNypfBE0JMVJesdw0a9+fCb3DA=",
      "url": "index.html"
    },
    {
      "hash": "sha256-eeSJpVUPaB8WV/aaHOBlik2BJ82ClFlmOPtHQmOBjuI=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-57uOHyiG7A4su/idyJlcX4nL63zWN0gM4dCAEsI2BDM=",
      "url": "post_images/20250719_TomlDocument.svg"
    }
  ]
};
