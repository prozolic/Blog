self.assetsManifest = {
  "version": "SNE+4RtW",
  "assets": [
    {
      "hash": "sha256-OHHIqtETA8sOsLrBrXP85NlpjUnVcjyfFiqiX+R6re4=",
      "url": "Blog.styles.css"
    },
    {
      "hash": "sha256-2iGqUFC5jqUP8H04S1yEgtnVDTMZ/WhKyi9cqDxT56A=",
      "url": "_framework/Blog.22hm6v0qsq.wasm"
    },
    {
      "hash": "sha256-bOHBDXqcHAs3zIjmR6QO/aZQX74Xh45s9G5VY8ffBu8=",
      "url": "_framework/CsToml.Extensions.Configuration.8x03qwifgf.wasm"
    },
    {
      "hash": "sha256-3gJ3XPqDqyux5jmIAeW6bomaO11o+zPDwkFxPW1GYzg=",
      "url": "_framework/CsToml.igxf6k9624.wasm"
    },
    {
      "hash": "sha256-K46uy62cWedrCpQn6lDEUo+V41p7PfjIuAFHZSqvWjI=",
      "url": "_framework/Microsoft.AspNetCore.Components.7dtuqdr1r9.wasm"
    },
    {
      "hash": "sha256-CWCZqVZuK9hqJlOK6ywJw5UgVWe0Je7+KtO55A+f03k=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.d31aoxs14p.wasm"
    },
    {
      "hash": "sha256-bqToPI/iL7iT4lMfZpUf8kdGiSYBPn6stJz70lt8O9Q=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.2kw3cyk0ye.wasm"
    },
    {
      "hash": "sha256-HX68hXxk6c08Jqozrmk7hkVzJbe5mt8HQhQbxPCtE6A=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.pxmc3jrvol.wasm"
    },
    {
      "hash": "sha256-48JXlZmcPLcNSAjqhbdbfTH4xHqaohlFANKKDx/B8l8=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.jsatnke3be.wasm"
    },
    {
      "hash": "sha256-UPJuvhAAIQZIY0doC/uzYNM5QzRPAAU1Pmb0Ifrcf9c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.wcgatl1fku.wasm"
    },
    {
      "hash": "sha256-Wi80UmFVOmdQaDRcxp7/2T/GEuCOmgUlM9sNp0LaWnw=",
      "url": "_framework/Microsoft.Extensions.Configuration.acm92ptx9n.wasm"
    },
    {
      "hash": "sha256-s5NDC8ouuFz/geKtgUbDxufmI+ao9OBcshJqHZ7nCUs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.lmexob41u0.wasm"
    },
    {
      "hash": "sha256-7S6kTaJc+9LgeS7EUElf4KtAd5iKmMPQDq8blLM0R9A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.b6byw5pilb.wasm"
    },
    {
      "hash": "sha256-MsoKFauzZ1Q66tlPtOkEZW/Bmz1VSbNGsLrEhcdKzmQ=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.e9a5j13hq3.wasm"
    },
    {
      "hash": "sha256-nzOhOhbqPp4A+JOtHIaacnQTp3N4+NjIXJwngjl/YE8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.zfy5eiubms.wasm"
    },
    {
      "hash": "sha256-tDVeIP9ZR14ldjVq/eMrl96QyGZ2/GBm9sQHIp0/4MM=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.k414ve2zji.wasm"
    },
    {
      "hash": "sha256-YO5x91yf17Td+qEVJo/kUm3f6fHgTTb09Zq+lVN97UA=",
      "url": "_framework/Microsoft.Extensions.Logging.0sb8g1j1zh.wasm"
    },
    {
      "hash": "sha256-wCWCP/8cnVnRXChftitCfDP5dfqI0K+u5H1Mszt8oGw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.w4167e73p5.wasm"
    },
    {
      "hash": "sha256-t2HV7rTyAyGOMt33GRIJREnlQtukzdhWo1v4EH2gtKg=",
      "url": "_framework/Microsoft.Extensions.Options.hizer6y0kq.wasm"
    },
    {
      "hash": "sha256-jniVbDAf9oTw4t4bWQ1+z8B+AOK2d0BUwwfVeIKPAIE=",
      "url": "_framework/Microsoft.Extensions.Primitives.i4ptzcb4ar.wasm"
    },
    {
      "hash": "sha256-h5dZbpobwVaeAlG8/7omx0OFtwdJP8CG6fx00P0ms3E=",
      "url": "_framework/Microsoft.JSInterop.5x9l7rt3xd.wasm"
    },
    {
      "hash": "sha256-rhpkBOcrE3Jka5EriY0f6+d/lxnwAWpcDQrLBwRBYfg=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ynpjm7kaw7.wasm"
    },
    {
      "hash": "sha256-wDIARruntc5/dGQ+0HLOwd3nW0gT5lonr/CMZQsaqug=",
      "url": "_framework/System.Collections.Concurrent.gs8dh5m2qf.wasm"
    },
    {
      "hash": "sha256-zmBe2VIV3qWmzL88uiDzg+81t09v76uMCo34+o+LoHg=",
      "url": "_framework/System.Collections.Immutable.mfwc4bib92.wasm"
    },
    {
      "hash": "sha256-rMML+SE2mNTq0SwMbSfU6ZxIuzk5SZA70q3N7Bm6ins=",
      "url": "_framework/System.Collections.cycj0h9c3n.wasm"
    },
    {
      "hash": "sha256-DHujPeYswdt0JOBw03JC11hmqQ+Vtb1K9fkbgtDLtTM=",
      "url": "_framework/System.ComponentModel.0n5errmvx8.wasm"
    },
    {
      "hash": "sha256-NoY8Mm86dn4WCbfb2VVxMJaDOOkscaS3m504gFCo80c=",
      "url": "_framework/System.ComponentModel.Primitives.m8shxrhray.wasm"
    },
    {
      "hash": "sha256-tQqaJlmlAM+Zk+M8pEt/C1n1YbQWnF67zGkF3iP5xMQ=",
      "url": "_framework/System.Console.fjxyveej0f.wasm"
    },
    {
      "hash": "sha256-U8B2XGEN7fh+APzAGfFM/T8I/hus04qSLALIXya/Gj8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.30xhrlp8k2.wasm"
    },
    {
      "hash": "sha256-8mACtyPHM5cZk3Ai58Sh++UHx3UuE6ITgUDwCngiPGI=",
      "url": "_framework/System.IO.FileSystem.Watcher.i8olzkexwp.wasm"
    },
    {
      "hash": "sha256-XzDBdGq7YMok7HvhoSgJK2SG5YnBqgbSbj7y+8/5/UI=",
      "url": "_framework/System.IO.Hashing.zvmiwv33ql.wasm"
    },
    {
      "hash": "sha256-PJhwW3fS28zc+/2DTzrWtJenyzm5Na1m44JaekgWklw=",
      "url": "_framework/System.IO.Pipelines.cijcq8k76k.wasm"
    },
    {
      "hash": "sha256-zqtz8pfHJasTfkJdw2TfuRnAT3+er7ysHOcPpr5M++w=",
      "url": "_framework/System.Linq.in84rnfs3h.wasm"
    },
    {
      "hash": "sha256-WoidKGJrOrFu1qS++LxgDlmJ84sKR/QxeXgQYLUMbGU=",
      "url": "_framework/System.Memory.mtbmbibiyr.wasm"
    },
    {
      "hash": "sha256-6TUViNbjhdDsimWsthuXrFhNKBgmZZPGpWM4FVXopNY=",
      "url": "_framework/System.Net.Http.7ob4ihsfu3.wasm"
    },
    {
      "hash": "sha256-kP6Jwg/kcnMSLsbn9cs4LeL8/1blbyVxXkA6U83aEz4=",
      "url": "_framework/System.Net.Primitives.gw4jr5ricc.wasm"
    },
    {
      "hash": "sha256-vClZPSEW++vobK/oRIGCUMxSWYDpJ8hQ1EaJuUBZDB0=",
      "url": "_framework/System.Private.CoreLib.443er9pmfi.wasm"
    },
    {
      "hash": "sha256-VkUot4DUqDkr6fq2aBbI3ouW55LFZRoYLU60dIo0j5g=",
      "url": "_framework/System.Private.Uri.q3d4ii1h35.wasm"
    },
    {
      "hash": "sha256-JfJggi7xUg1PnI677BtGJbG0snOuJ6dUET9SdWBf6r0=",
      "url": "_framework/System.Runtime.9n6q6upjqd.wasm"
    },
    {
      "hash": "sha256-cH/BrU2Hn9rDjkwjopwMWUarh6MRA/i5tZlJWTzrO3o=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4rcsp2xpv0.wasm"
    },
    {
      "hash": "sha256-FMeVpNoYzSfWCZs/DsazTmgoBfzfHwMCRrFltYq9Hfg=",
      "url": "_framework/System.Runtime.Numerics.kmo1mg3nyx.wasm"
    },
    {
      "hash": "sha256-9bDg2WTEODlUxDGkO/cI7JtEWsbSQyHzZswG6DTKzHE=",
      "url": "_framework/System.Runtime.Serialization.Primitives.5g7d61inoh.wasm"
    },
    {
      "hash": "sha256-Rf3UIU6zwPyw86Bn3jMsZx01ZMkdKtXJvxb03NNV2uU=",
      "url": "_framework/System.Security.Cryptography.3y7mpecv7s.wasm"
    },
    {
      "hash": "sha256-flEgOciRBSZuy+w3GMI9J++G568kb+ZDjBoelvLhl4A=",
      "url": "_framework/System.Text.Encodings.Web.q9uhuoqrv7.wasm"
    },
    {
      "hash": "sha256-bk455YJVPtM+2AqLhg6i9JmcJK9GzstPv5rkzEVFWkI=",
      "url": "_framework/System.Text.Json.m6kl509dpg.wasm"
    },
    {
      "hash": "sha256-57HxVA5q6TUwgi9a7e2xqrer7Lz+Kgvc5oxsU2lY1tY=",
      "url": "_framework/System.Text.RegularExpressions.nci05k6c78.wasm"
    },
    {
      "hash": "sha256-VjGThAw2SRHwYUmAxLUKCbUPIbXUAiayWfJHDlvjA3I=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-NIAKIOnbhyj2YnxvsmFPhnUToJVMmUfm5F7735WvlC0=",
      "url": "_framework/dotnet.native.sw3kjvylf3.js"
    },
    {
      "hash": "sha256-TRKIf1CrfARnBtpK7m/M3QAtwlEiGI/2sBz6vyv+wt0=",
      "url": "_framework/dotnet.native.xjogudkzhk.wasm"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-rnqXCovcfgHmKC8LaoxQtxQ01TAE1l4x+LYbpxdSh5k=",
      "url": "appSettings.toml"
    },
    {
      "hash": "sha256-aVNlpsPsi4dBkW0q2m0XVRKmG7YOxwNocKY0O2kO2es=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-zfZDxn93Pgt+mw0ggQTfd7xRgIQaski3U7yZS9xOsj0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-Zg+XZRI+LkFGenBWHVd1Ke5mFxce2FKbbM3+zLMyAKo=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-nMPM066johB7WfL3lmbDgNFkbIyMo8irk6g9SzT+ARY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-6kXckefe5XHvO0l6SVtREzHSLnQIJNMdTia3TUHb78U=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-57uOHyiG7A4su/idyJlcX4nL63zWN0gM4dCAEsI2BDM=",
      "url": "post_images/20250719_TomlDocument.svg"
    },
    {
      "hash": "sha256-Yk224G0PbdHeIhMr0aRhgcpnRRk7oElnZ7Q/TF6RwTY=",
      "url": "post_images/20250911_service-worker.published.js.png"
    }
  ]
};
